<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<style type="text/css">
.heading {
	font-weight: bold;
	text-align: center;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 24px;
	color: #333;
}
.subhead {
	text-align: center;
	font-weight: bold;
	font-style: italic;
}
.subhead {
	font-size: 24px;
}
body {
	background-image: url();
}
</style>
</head>

<body>
<table width="1000" height="403" border="0" align="center">
  <tr>
    <td height="229" valign="top"><table width="993" height="438" border="0" align="center">
      <tr>
        <td height="173" colspan="2" bgcolor="#999999" class="heading">CHAITANYA BHARATHI INSTITUTE OF TECHNOLOGY</td>
        </tr>
      <tr>
        <td width="450" height="257" bgcolor="#00FFFF" class="subhead"><a href="studentlogin.php">STUDENT</a></td>
        <td width="481" bgcolor="#CC99CC" class="subhead"><a href="admin.php">ADMIN</a></td>
      </tr>
    </table></td>
  </tr>
</table>
</body>
</html>
