<?PHP

session_start();
include ('connection.php');
if (!(isset($_SESSION['login_user']) && $_SESSION['login_user'] != '')) {

header ("Location: index.php");

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php


$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
if (empty($_POST['amount']) ) {
$error = "Insufficient details";
echo $error;
}
else
{	
	$did=$_SESSION['id'];
// Define $username and $password
$amount=$_POST['amount'];
$query = mysql_query("select amountpaid,amounttobepaid from student where id ='$did'", $connection);

while($row=mysql_fetch_array($query))
{
$finalap=$row['amountpaid']+$amount;
$finalatp=$row['amounttobepaid']-$amount;
}
					

$query1 = mysql_query("Update student Set amountpaid = '$finalap', amounttobepaid='$finalatp' Where id = '$did'", $connection);


if (!$query1) {
echo "error"; 
} else {
	$email=$row['emailid'];

	include("phpmailer\mailtestfee.php");
	

}
mysql_close($connection); // Closing Connection
}
}
?>

</body>
</html>