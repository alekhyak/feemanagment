<?php 
require("class.phpmailer.php");
define('GUSER', ''); // GMail username
define('GPWD', ''); // GMail password
function smtpmailer($to, $from, $from_name, $subject, $body) { 
	global $error;
	$mail = new PHPMailer();  // create a new object
	$mail->IsSMTP(); // enable SMTP
	$mail->SMTPDebug = 0;  // debugging: 1 = errors and messages, 2 = messages only
	$mail->SMTPAuth = true;  // authentication enabled
	$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
	$mail->Host = 'smtp.gmail.com';
	$mail->Port = 465; 
	$mail->Username = GUSER;  
	$mail->Password = GPWD;           
	$mail->SetFrom($from, $from_name);
	$mail->Subject = $subject;
	$mail->Body = $body;
	$mail->AddAddress($to);
	if(!$mail->Send()) {
		$error = 'Mail error: '.$mail->ErrorInfo; 
		return false;
	} else {
		$error = 'Message sent!';
		echo $error;
		return true;
	}
}
$connection = mysql_connect("localhost", "root", "allu1995");
$db = mysql_select_db("cbitfee", $connection);
$query = mysql_query("select *from student where amountpaid < totalfee and branch='cse'", $connection);
while($row=mysql_fetch_array($query))
						{	
						$amount=$row['amounttobepaid'];
						$name=$row['name'];
						smtpmailer($row['emailid'], 'alekhya2009@gmail.com', 'CBIT', 'Fee Due Alert', "Heloo $name!! you have fee due of $amount.Please pay it as fast as possible.");
						}
						


?>
