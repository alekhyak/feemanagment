<?php
session_start();
include ('connection.php');
// SQL query to fetch information of registerd users and finds user match.
$user=$_SESSION['login_user'];
$password=$_POST['password'];
$query = mysql_query("update student set pswd='$password' where id='$user' ", $connection);

if ($query== 1) {
header("location:passwordsuccess.php"); 
} else {
$error = "error";
}
mysql_close($connection); // Closing Connection

?>
