<table border="0"  >
<tr >
<td style="padding:15px">s.no</td>
<td style="padding:15px">id</td>
<td style="padding:15px">feedue</td>

</tr>
<?php
	
		  include ('connection.php');
			// SQL query to fetch information of registerd users and finds user match.
		

$query = mysql_query("select *from student where amountpaid < totalfee and branch='it'", $connection);
$i=1;
						while($row=mysql_fetch_array($query))
						{		
 ?>							<tr>
 								<td style="padding:15px"><?php echo $i++; ?></td>
 								<td style="padding:15px"><?php echo $row['id'] ;?> </td>
						
							<td style="padding:15px"><?php echo $row['amounttobepaid'];?></td>
                            </tr>
                            <?php
						}

?>
<form action="phpmailer/mailtest2.php">

<input type="submit" value="emailalert" /> 
</form>
