<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.heading {	font-weight: bold;
	text-align: center;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 24px;
	color: #333;
}
.subhead {	text-align: center;
	font-weight: bold;
	font-style: italic;
}
.subhead {	font-size: 24px;
}
#form1 p {
	text-align: center;
}
</style>
</head>

<body>
<table width="1000" height="403" border="0" align="center">
  <tr>
    <td height="229" valign="middle"><form id="form1" name="loginid" method="post" action="adminverify.php">
      <p>
        <label for="textfield">loginid</label>
        <input type="text" name="id" id="textfield" />
      </p>
      <p>
        <label for="textfield2">password</label>
        <input type="password" name="password" id="textfield2" />
      </p>
      <p>
        
        <input name="login" type="submit" id="textfield3" value="login" />
      </p>
    </form></td>
  </tr>
</table>
</body>
</html>