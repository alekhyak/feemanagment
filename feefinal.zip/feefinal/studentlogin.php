<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body><table width="500" height="335" border="0" align="center">
  <tr>
    <td align="center" valign="middle"><form id="form1" name="form1" method="post" action="studentidexist.php">
      <p>
        <label for="textfield">id</label>
        <input type="text" name="id" id="textfield" /><br/>
        <br/>
        <label for="textfield">password</label>
        <input type="password" name="pswd" id="textfield" />

      </p>
      <p>
      
        <input type="submit" name="submit" id="textfield2" />
      </p>
    </form></td>
  </tr>
</table>

</body>
</html>