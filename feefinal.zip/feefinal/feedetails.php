<?PHP

session_start();

if (!(isset($_SESSION['login_user']) && $_SESSION['login_user'] != '')) {

header ("Location: index.php");

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.adminh {	text-align: center;
}
.adminh {	text-align: center;
}
.adminh {	text-align: center;
}
.adminh {	text-align: center;
}
.welcome {	font-size: 18px;
}
</style>
</head>

<body>
<table width="1000" height="403" border="0" align="center">
  <tr>
    <td valign="top"><table width="1000" height="68" border="0">
      <tr>
        <td width="246" height="64" bgcolor="#00FFFF" class="adminh"><a href="addstudent.php">ADD STUDENT</a></td>
        <td width="247" bgcolor="#FF66FF" class="adminh"><a href="payfee.php">PAY FEE</a></td>
        <td width="246" bgcolor="#99FFFF" class="adminh"><a href="feedue.php">FEE DUE</a></td>
        <td width="243" bgcolor="#CC99FF" class="adminh"><a href="logout.php">LOGOUT</a></td>
      </tr>
    </table>
      <table width="662" height="346" border="0" align="center">
        <tr>
          <td height="340" align="center" valign="top" class="welcome"><table width="598" height="323" border="1">
            <tr>
              <td width="298" height="269" align="center" valign="middle">
			  <?php 
			  echo "<u><b>STUDENT DETAILS</u></b>"."<br/>";
			  $did=$_SESSION['id'];
			  	
			  // Establishing Connection with Server by passing server_name, user_id and password as a parameter
						$connection = mysql_connect("localhost", "root", "allu1995");
			// Selecting Database
						$db = mysql_select_db("cbitfee", $connection);
			// SQL query to fetch information of registerd users and finds user match.
						$query = mysql_query("select *from student where id ='$did'", $connection);
						while($row=mysql_fetch_array($query))
						{		echo "name"." "." ="." " .$row['name'] . "<br/>";
							echo "studentid"." "." ="." " .$row['id'] . "<br/>";
							echo "branch"." "." ="." ".$row['branch']."<br/>";
							echo "category"." "." ="." ".$row['category']."<br/>";
							echo "totalfee"." "." ="." ".$row['totalfee']."<br/>";
							echo "amountpaid"." "." ="." ".$row['amountpaid']."<br/>";
							echo "amounttobepaid"." "." ="." ".$row['amounttobepaid']."<br/>";
						}
						
				mysql_close($connection); // Closing Connection

 
			  ?>&nbsp;</td>
              <td width="284"><form id="form1" name="form1" method="post" action="feesubmited.php">
                <p>
                  <label for="textfield">amount</label>
                  <input type="text" name="amount" id="textfield" />
                </p>
                <p>
                  
                 <center ><input type="submit" name="submit" value="submit" id="textfield2" /></center>
                </p>
              </form></td>
            </tr>
          </table></td>
        </tr>
    </table></td>
  </tr>
</table>
</body>
</html>