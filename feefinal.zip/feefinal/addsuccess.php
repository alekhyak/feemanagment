<?PHP

session_start();
include ('connection.php');

if (!(isset($_SESSION['login_user']) && $_SESSION['login_user'] != '')) {

header ("Location: index.php");

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php

$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
if (empty($_POST['name'])|| empty($_POST['id']) || empty($_POST['branch']) || empty($_POST['category']) ||empty($_POST['totalfee'])
||empty($_POST['emailid'])) {
$error = "Insufficient details";
echo $error;
}
else
{
// Define $username and $password
$name=$_POST['name'];
$id=$_POST['id'];
$branch=$_POST['branch'];
$category=$_POST['category'];
$totalfee=$_POST['totalfee'];
$emailid=$_POST['emailid'];
$pswd="cbithyd";
include ('connection.php');
// SQL query to fetch information of registerd users and finds user match.
$query = mysql_query("insert into student (name,id,branch,category,emailid,totalfee,amounttobepaid,pswd) values('$name','$id','$branch','$category','$emailid','$totalfee','$totalfee','$pswd')", $connection);

if (!$query) {
echo "error"; 
} else {

	header("location: addsuccessresult.php");
	

}
mysql_close($connection); // Closing Connection
}
}
?>

</body>
</html>