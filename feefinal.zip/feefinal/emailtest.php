<?php
	
						include ('connection.php');
		 
		
$query = mysql_query("select *from student where amountpaid < totalfee and branch='cse'", $connection);

						while($row=mysql_fetch_array($query))
						{	
							$email=$row['emailid'];
						include("phpmailer\mailtest.php");
						}
?>