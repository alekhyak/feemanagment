<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
session_start(); // Starting Session
include ('connection.php');
$error=''; // Variable To Store Error Message
if (isset($_POST['submit'])) {
if (empty($_POST['id']) || empty($_POST['pswd'])) {
$error = "insufficent details";
echo $error;
}
else
{
// Define $username
$username=$_POST['id'];
$password=$_POST['pswd'];
// SQL query to fetch information of registerd users and finds user match.
$query = mysql_query("select * from student where  id='$username' and pswd='$password'", $connection);
$rows = mysql_num_rows($query);
if ($rows == 1) {
$_SESSION['login_user']=$username; // Initializing Session
header("location: student.php"); // Redirecting To Other Page
} else {
$error = "Username  is invalid";
echo $error;
}
mysql_close($connection); // Closing Connection
}
}
?>
</body>
</html>