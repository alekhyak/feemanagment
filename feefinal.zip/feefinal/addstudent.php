<?PHP

session_start();

if (!(isset($_SESSION['login_user']) && $_SESSION['login_user'] != '')) {

header ("Location: index..php");

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.adminh {	text-align: center;
}
.adminh {	text-align: center;
}
.adminh {	text-align: center;
}
.adminh {	text-align: center;
}
.welcome {	font-size: 18px;
}
</style>
<script type="text/javascript">
function ValidateEmail()   
{  
 if (/^\w+([\.-]?\w+)*@gmail.com$/.test(document.form1.emailid.value))  
  {  
    return (true)  
  }
  else if (/^\w+([\.-]?\w+)*@yahoo.com$/.test(document.form1.emailid.value))  
  {  
    return (true)  
  }
  else
  {
	    alert("You have entered an invalid email address!") ;
	 document.form1.emailid.focus() ;
    return (false) ;
  }
	return( true ); 
}  

</script>
</head>

<body>

<table width="1000" height="403" border="0" align="center">
  <tr>
    <td valign="top"><table width="1000" height="68" border="0">
      <tr>
        <td width="246" height="64" bgcolor="#00FFFF" class="adminh"><a href="addstudent.php">ADD STUDENT</a></td>
        <td width="247" bgcolor="#FF66FF" class="adminh"><a href="payfee.php">PAY FEE</a></td>
        <td width="246" bgcolor="#99FFFF" class="adminh"><a href="feedue.php">FEE DUE</a></td>
        <td width="243" bgcolor="#CC99FF" class="adminh"><a href="logout.php">LOGOUT</a></td>
      </tr>
    </table>
      <table width="569" height="306" border="1" align="center">
        <tr>
          <td align="center" class="welcome"><form id="form1" name="form1" method="post" action="addsuccess.php" onsubmit="return(ValidateEmail());">
            <p>
            <label for="textfield">name</label>
              <input type="text" name="name" id="name" />
              <br/>
              <br/>
              <label for="textfield">studentid</label>
              <input type="text" name="id" id="textfield" />
              <label for="select"><br />
                <br />
                branch</label>
              <select name="branch" id="select">
               <option disabled selected> -- select an option -- </option>
                <option >cse</option>
                <option>ece</option>
                <option>it</option>
              </select>
           
              </p>
            <p>
              <label for="select2">category</label>
              <select name="category" id="select2">
               <option disabled selected> -- select an option -- </option>
              <option >NRI</option>
              <option>A cat</option>
              <option>B cat</option>
              <option>Mgmt</option>
              </select>
            </p>
            <p>
              <label for="textfield3">emailid</label>
              <input type="text" name="emailid" id="textfield3" />
            </p>
            <p>
              <label for="select3">totalfee</label>
              <select name="totalfee" id="select3">
               <option disabled selected> -- select an option -- </option>
              <option >100000</option>
              <option>35000</option>
              <option>50000</option>
              <option>600000</option>
              </select>
            </p>
            <p>&nbsp;</p>
            <p>
              
              <input type="submit" name="submit" id="textfield2" />
            </p>
            <p>&nbsp;</p>
          </form></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>