<?PHP

session_start();

if (!(isset($_SESSION['login_user']) && $_SESSION['login_user'] != '')) {

header ("Location: index.php");

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.adminh {	text-align: center;
}
.adminh {	text-align: center;
}
.adminh {	text-align: center;
}
.adminh {	text-align: center;
}
.welcome {	font-size: 18px;
}
</style>
</head>

<body>
<table width="1000" height="403" border="0" align="center">
  <tr>
    <td valign="top"><table width="1000" height="68" border="0">
      <tr>
        <td width="10" height="64"  class="adminh"></td>
        <td width="300" bgcolor="#99FF66"  class="adminh"><a href="student.php">Details</a></td>
        <td width="306"  class="adminh" bgcolor="#CC66FF" ><a href="changepassword.php"> Change password</a></td>
        <td width="300"  class="adminh" bgcolor="#FFFF99"><a href="logout.php">Logout</a></td>
      </tr>
      </table>
      
     
     <table width="662" height="346" border="0" align="center">
        <tr>
          <td height="340" align="center" valign="top" class="welcome"><table width="598" height="323" border="1">
            <tr>
              <td height="269" align="center" valign="middle">
              <p>Password changed succesfully</p>
      </table>
      </td>
      <tr>
      </table>
     
         
</body>
</html>