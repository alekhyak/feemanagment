<?PHP

session_start();

if (!(isset($_SESSION['login_user']) && $_SESSION['login_user'] != '')) {

header ("Location: index..php");

}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<style type="text/css">
.adminh {text-align: center;
}
.adminh {text-align: center;
}
.adminh {text-align: center;
}
.adminh {text-align: center;
}
.welcome {font-size: 18px;
}
</style>
</head>

<body>

<table width="1000" height="403" border="0" align="center">
  <tr>
    <td valign="top"><table width="1000" height="68" border="0">
      <tr>
        <td width="246" height="64" bgcolor="#00FFFF" class="adminh"><a href="addstudent.php">ADD STUDENT</a></td>
        <td width="247" bgcolor="#FF66FF" class="adminh"><a href="payfee.php">PAY FEE</a></td>
        <td width="246" bgcolor="#99FFFF" class="adminh"><a href="feedue.php">FEE DUE</a></td>
        <td width="243" bgcolor="#CC99FF" class="adminh"><a href="logout.php">LOGOUT</a></td>
      </tr>
    </table>
      <table width="569" height="306" border="1" align="center">
        <tr>
          <td align="center" class="welcome">&nbsp;
            <?php
			if (isset($_POST['submit'])) {
if (empty($_POST['branch'])) {
$error = "Insufficient details";
echo $error;
}
else
{
			
		  include ('connection.php');
				if($_POST['branch']=="cse")
				{
						include("testtable.php");
						
				}
				if($_POST['branch']=="ece")
				{
							include("testtable1.php");
				}
				if($_POST['branch']=="it")
				{
						include("testtable2.php");
				}
				
				mysql_close($connection); // Closing Connection

 
}
}
?></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>