<?php 
// Establishing Connection with Server by passing server_name, user_id and password as a parameter
						$connection = mysql_connect("localhost", "root", "allu1995");
			// Selecting Database
						$db = mysql_select_db("cbitfee", $connection);
			// SQL query to fetch information of registerd users and finds user match.
?>		